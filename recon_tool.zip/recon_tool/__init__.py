"""
OSINT RECON Tool - Proof of Concept
A tool to orchestrate multiple OSINT reconnaissance tools.
"""

__version__ = "0.1.0"

